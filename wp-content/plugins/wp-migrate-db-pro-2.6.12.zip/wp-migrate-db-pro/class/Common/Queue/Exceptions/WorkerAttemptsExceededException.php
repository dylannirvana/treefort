<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Exceptions;

use Exception;

class WorkerAttemptsExceededException extends Exception {
	//
}

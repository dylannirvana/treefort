<?php

namespace DeliciousBrains\WPMDBMF\CliCommand;

class MediaFilesCli {
    //Silence is golden.
}

<?php

namespace DeliciousBrains\WPMDBMF;

class MediaFilesRemote {
    //Silence is golden.
}
